<div class="col-md-4 col-sm-12 mt-3 shadow-sm bg-body rounded">
    <?php dynamic_sidebar('main-sidebar'); ?>
</div>